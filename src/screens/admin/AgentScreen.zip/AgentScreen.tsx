import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  FlatList, KeyboardAvoidingView, Platform, ActivityIndicator,
  Animated, Easing, StatusBar, Vibration,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Toast from 'react-native-toast-message';
import * as Speech from 'expo-speech';
import {
  ExpoSpeechRecognitionModule,
  useSpeechRecognitionEvent,
} from 'expo-speech-recognition';
import { colors } from '../../theme/colors';

// ─────────────────────────────────────────────────────────────────────────────
// ⚠️  Apna n8n webhook URL yahan daalo
// ─────────────────────────────────────────────────────────────────────────────
const N8N_WEBHOOK_URL = 'https://whatsapp-lead-n8n.ndna0p.easypanel.host/webhook/test';

// ─── Types ────────────────────────────────────────────────────────────────────
type MicState = 'idle' | 'listening' | 'processing';
type MsgRole  = 'user' | 'agent';
interface Msg  { id: string; role: MsgRole; text: string; ts: Date; status?: 'sending' | 'sent' | 'error'; }

const WELCOME: Msg = {
  id: 'welcome', role: 'agent', ts: new Date(), status: 'sent',
  text: "Hello! I'm your AI Sales Agent. Tap the mic and speak — phone seedha text banayega. Ya type karo neeche.",
};

const SESSION_ID = `session_${Date.now()}`;

// ─── Pulse Orb ────────────────────────────────────────────────────────────────
function PulseOrb({ mic, speaking }: { mic: MicState; speaking: boolean }) {
  const rings = [
    useRef(new Animated.Value(1)).current,
    useRef(new Animated.Value(1)).current,
    useRef(new Animated.Value(1)).current,
  ];
  const active = mic === 'listening' || speaking;
  const color  = speaking ? '#10B981' : mic === 'listening' ? '#EF4444' : colors.primary;

  useEffect(() => {
    if (!active) { rings.forEach(r => r.setValue(1)); return; }
    const anims = rings.map((r, i) =>
      Animated.loop(Animated.sequence([
        Animated.delay(i * 260),
        Animated.timing(r, { toValue: speaking ? 2.5 : 2.0, duration: 700, easing: Easing.out(Easing.ease), useNativeDriver: true }),
        Animated.timing(r, { toValue: 1, duration: 700, easing: Easing.in(Easing.ease), useNativeDriver: true }),
      ]))
    );
    anims.forEach(a => a.start());
    return () => anims.forEach(a => a.stop());
  }, [active, speaking]);

  return (
    <View style={orbS.wrap}>
      {rings.map((r, i) => (
        <Animated.View key={i} style={[orbS.ring, {
          width: 76 + i * 26, height: 76 + i * 26,
          borderRadius: (76 + i * 26) / 2,
          backgroundColor: color + ['22', '12', '07'][i],
          transform: [{ scale: r }],
        }]} />
      ))}
      <View style={[orbS.core, { backgroundColor: color, shadowColor: color }]}>
        <Ionicons
          name={speaking ? 'volume-high' : mic === 'listening' ? 'mic' : 'sparkles'}
          size={30} color="#fff"
        />
      </View>
    </View>
  );
}
const orbS = StyleSheet.create({
  wrap: { width: 155, height: 155, alignItems: 'center', justifyContent: 'center' },
  ring: { position: 'absolute' },
  core: { width: 76, height: 76, borderRadius: 38, alignItems: 'center', justifyContent: 'center', elevation: 12, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 12 },
});

// ─── Typing dots ──────────────────────────────────────────────────────────────
function TypingDots() {
  const dots = [
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
  ];
  useEffect(() => {
    const anims = dots.map((d, i) =>
      Animated.loop(Animated.sequence([
        Animated.delay(i * 140),
        Animated.timing(d, { toValue: 1, duration: 380, useNativeDriver: true }),
        Animated.timing(d, { toValue: 0, duration: 380, useNativeDriver: true }),
        Animated.delay(280),
      ]))
    );
    anims.forEach(a => a.start());
    return () => anims.forEach(a => a.stop());
  }, []);
  return (
    <View style={dotS.row}>
      <LinearGradient colors={[colors.primary, colors.primaryDark]} style={dotS.av}>
        <Ionicons name="sparkles" size={13} color="#fff" />
      </LinearGradient>
      <View style={dotS.bubble}>
        {dots.map((d, i) => (
          <Animated.View key={i} style={[dotS.dot, {
            opacity: d,
            transform: [{ translateY: d.interpolate({ inputRange: [0, 1], outputRange: [0, -5] }) }],
          }]} />
        ))}
      </View>
    </View>
  );
}
const dotS = StyleSheet.create({
  row:    { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 16, marginVertical: 4 },
  av:     { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginRight: 8 },
  bubble: { backgroundColor: colors.card, borderRadius: 18, borderBottomLeftRadius: 4, paddingHorizontal: 16, paddingVertical: 14, flexDirection: 'row', gap: 5, elevation: 2 },
  dot:    { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
});

// ─── Message Bubble ───────────────────────────────────────────────────────────
function Bubble({ msg, onSpeak }: { msg: Msg; onSpeak: (t: string) => void }) {
  const isUser = msg.role === 'user';
  const fade   = useRef(new Animated.Value(0)).current;
  const slide  = useRef(new Animated.Value(isUser ? 36 : -36)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade,  { toValue: 1, duration: 260, useNativeDriver: true }),
      Animated.spring(slide, { toValue: 0, tension: 65, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);
  const time = msg.ts.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  return (
    <Animated.View style={[bS.row, isUser ? bS.rowR : bS.rowL, { opacity: fade, transform: [{ translateX: slide }] }]}>
      {!isUser && (
        <LinearGradient colors={[colors.primary, colors.primaryDark]} style={bS.av}>
          <Ionicons name="sparkles" size={13} color="#fff" />
        </LinearGradient>
      )}
      <View style={[bS.bubble, isUser ? bS.bUser : bS.bAgent]}>
        <Text style={[bS.text, isUser ? bS.tUser : bS.tAgent]}>{msg.text}</Text>
        <View style={bS.foot}>
          <Text style={[bS.time, isUser && bS.timeU]}>{time}</Text>
          {isUser && (
            <Ionicons
              name={msg.status === 'sending' ? 'time-outline' : msg.status === 'error' ? 'alert-circle' : 'checkmark-done'}
              size={11}
              color={msg.status === 'error' ? colors.error : 'rgba(255,255,255,0.55)'}
              style={{ marginLeft: 3 }}
            />
          )}
          {!isUser && (
            <TouchableOpacity
              onPress={() => onSpeak(msg.text)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={{ marginLeft: 6 }}
            >
              <Ionicons name="volume-medium-outline" size={14} color={colors.textLight} />
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Animated.View>
  );
}
const bS = StyleSheet.create({
  row:    { flexDirection: 'row', marginVertical: 3, paddingHorizontal: 14, alignItems: 'flex-end' },
  rowR:   { justifyContent: 'flex-end' },
  rowL:   { justifyContent: 'flex-start' },
  av:     { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginRight: 8, marginBottom: 2 },
  bubble: { maxWidth: '78%', borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10, elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.08, shadowRadius: 4 },
  bUser:  { backgroundColor: colors.primary, borderBottomRightRadius: 4 },
  bAgent: { backgroundColor: colors.card, borderBottomLeftRadius: 4 },
  text:   { fontSize: 15, lineHeight: 22 },
  tUser:  { color: '#fff' },
  tAgent: { color: colors.textPrimary },
  foot:   { flexDirection: 'row', alignItems: 'center', marginTop: 3, justifyContent: 'flex-end' },
  time:   { fontSize: 10, color: colors.textLight },
  timeU:  { color: 'rgba(255,255,255,0.55)' },
});

// ─── Quick chips ──────────────────────────────────────────────────────────────
const CHIPS = [
  { icon: 'people-outline',        label: 'Qualify a Lead' },
  { icon: 'call-outline',          label: 'Follow-up Script' },
  { icon: 'trending-up-outline',   label: 'Sales Tips' },
  { icon: 'document-text-outline', label: 'Handle Objections' },
];

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function AgentScreen() {
  const navigation = useNavigation<any>();
  const insets     = useSafeAreaInsets();
  const listRef    = useRef<FlatList>(null);

  const [msgs,      setMsgs]      = useState<Msg[]>([WELCOME]);
  const [inputText, setInputText] = useState('');
  const [thinking,  setThinking]  = useState(false);
  const [orbMode,   setOrbMode]   = useState(true);
  const [micState,  setMicState]  = useState<MicState>('idle');
  const [speaking,  setSpeaking]  = useState(false);
  const [liveText,  setLiveText]  = useState('');

  // ── expo-speech-recognition events ───────────────────────────────────────

  // Partial results — live dikhao
  useSpeechRecognitionEvent('result', (event) => {
    const text = event.results?.[0]?.transcript ?? '';
    if (event.isFinal) {
      // Final result — webhook pe bhejo
      if (text.trim()) {
        setInputText(text);
        setLiveText('');
        setMicState('processing');
        sendToWebhook(text);
      } else {
        setMicState('idle');
        setLiveText('');
      }
    } else {
      // Partial — live banner mein dikhao
      setLiveText(text);
      setInputText(text);
    }
  });

  useSpeechRecognitionEvent('error', (event) => {
    console.warn('Speech error:', event.error, event.message);
    setMicState('idle');
    setLiveText('');
    // aborted/cancelled pe toast mat dikhao
    if (event.error !== 'aborted' && event.error !== 'no-speech') {
      Toast.show({ type: 'error', text1: 'Voice error', text2: event.message ?? 'Dobara try karo.', position: 'top' });
    }
  });

  useSpeechRecognitionEvent('end', () => {
    // micState processing pe already set ho chuka hoga result event mein
    // agar idle pe end hua toh wapis idle karo
    setMicState(prev => prev === 'listening' ? 'idle' : prev);
  });

  // ── TTS — agent reply bolna ───────────────────────────────────────────────
  const speakText = useCallback(async (text: string) => {
    const isSp = await Speech.isSpeakingAsync();
    if (isSp) { Speech.stop(); setSpeaking(false); return; }
    setSpeaking(true);
    Speech.speak(text, {
      language: 'en-IN', pitch: 1.0, rate: 0.9,
      onDone:    () => setSpeaking(false),
      onError:   () => setSpeaking(false),
      onStopped: () => setSpeaking(false),
    });
  }, []);

  // ── Webhook call ──────────────────────────────────────────────────────────
  const sendToWebhook = useCallback(async (text: string) => {
    if (!text.trim()) { setMicState('idle'); return; }
    if (orbMode) setOrbMode(false);
    Vibration.vibrate(25);

    const userMsg: Msg = {
      id: `u${Date.now()}`, role: 'user',
      text: text.trim(), ts: new Date(), status: 'sending',
    };
    setMsgs(prev => [...prev, userMsg]);
    setInputText('');
    setThinking(true);

    try {
      const res = await fetch(N8N_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type:      'text',
          sessionId: SESSION_ID,
          message:   text.trim(),
          timestamp: new Date().toISOString(),
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const reply = data?.reply || data?.output || data?.message || data?.text || 'No response.';

      setMsgs(prev => prev.map(m => m.id === userMsg.id ? { ...m, status: 'sent' } : m));
      const agentMsg: Msg = {
        id: `a${Date.now()}`, role: 'agent',
        text: reply, ts: new Date(), status: 'sent',
      };
      setMsgs(prev => [...prev, agentMsg]);
      speakText(reply);

    } catch (err: any) {
      setMsgs(prev => prev.map(m => m.id === userMsg.id ? { ...m, status: 'error' } : m));
      Toast.show({ type: 'error', text1: 'Agent unavailable', text2: err.message, position: 'top' });
    } finally {
      setThinking(false);
      setMicState('idle');
    }
  }, [orbMode, speakText]);

  const scrollBottom = useCallback(() => {
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 80);
  }, []);
  useEffect(() => { scrollBottom(); }, [msgs, thinking]);

  // ── Mic press ─────────────────────────────────────────────────────────────
  const handleMic = useCallback(async () => {
    if (micState === 'listening') {
      ExpoSpeechRecognitionModule.stop();
      return;
    }
    if (micState === 'processing' || thinking) return;

    // Permission check
    const { granted } = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    if (!granted) {
      Toast.show({ type: 'error', text1: 'Mic permission nahi mila', position: 'top' });
      return;
    }

    try {
      Speech.stop(); setSpeaking(false);
      setLiveText('');
      setInputText('');
      setMicState('listening');
      if (orbMode) setOrbMode(false);
      Vibration.vibrate(40);

      ExpoSpeechRecognitionModule.start({
        lang: 'hi-IN',           // Hindi + Hinglish dono
        interimResults: true,    // live partial results
        continuous: false,
      });
    } catch (err: any) {
      setMicState('idle');
      Toast.show({ type: 'error', text1: 'Mic start failed', text2: err.message, position: 'top' });
    }
  }, [micState, thinking, orbMode]);

  const handleNewChat = () => {
    Speech.stop(); setSpeaking(false);
    ExpoSpeechRecognitionModule.abort();
    setMsgs([WELCOME]); setOrbMode(true); setThinking(false);
    setMicState('idle'); setInputText(''); setLiveText('');
  };

  const micIcon  = micState === 'listening' ? 'stop-circle' : micState === 'processing' ? 'hourglass-outline' : 'mic';
  const micColor = micState === 'listening' ? '#EF4444'     : micState === 'processing' ? colors.warning       : colors.primary;
  const statusLabel =
    speaking                  ? 'Speaking…'   :
    micState === 'listening'  ? 'Listening…'  :
    micState === 'processing' ? 'Processing…' : 'Online';

  return (
    <SafeAreaView style={s.safe} edges={['top', 'left', 'right']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primaryDark} />

      {/* ── Header ── */}
      <LinearGradient
        colors={[colors.primaryDark, colors.primary]}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
        style={s.header}
      >
        <View style={s.hL}>
          <View style={s.badge}><Ionicons name="sparkles" size={16} color="#fff" /></View>
          <View>
            <Text style={s.hTitle}>AI Sales Agent</Text>
            <View style={s.sRow}>
              <View style={[s.sDot, {
                backgroundColor:
                  speaking                  ? '#FBBF24' :
                  micState === 'listening'  ? '#EF4444' : '#4ADE80',
              }]} />
              <Text style={s.sTxt}>{statusLabel}</Text>
            </View>
          </View>
        </View>
        <View style={s.hR}>
          <TouchableOpacity style={s.hBtn} onPress={handleNewChat}>
            <Ionicons name="add-circle-outline" size={22} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={s.hBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="close" size={22} color="#fff" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>

        {/* ── Orb Hero ── */}
        {orbMode ? (
          <View style={s.hero}>
            <PulseOrb mic={micState} speaking={speaking} />
            <Text style={s.heroTitle}>Tap mic to speak</Text>
            <Text style={s.heroSub}>
              Phone ka Google/Apple STT seedha text banega{'\n'}
              Koi API nahi · Koi cost nahi
            </Text>
            <View style={s.chips}>
              {CHIPS.map((c, i) => (
                <TouchableOpacity key={i} style={s.chip} onPress={() => sendToWebhook(c.label)} activeOpacity={0.75}>
                  <Ionicons name={c.icon as any} size={14} color={colors.primary} />
                  <Text style={s.chipTxt}>{c.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ) : (
          <FlatList
            ref={listRef}
            data={msgs}
            keyExtractor={m => m.id}
            renderItem={({ item }) => <Bubble msg={item} onSpeak={speakText} />}
            contentContainerStyle={{ paddingTop: 12, paddingBottom: 6 }}
            ListFooterComponent={(thinking || micState === 'processing') ? <TypingDots /> : null}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={scrollBottom}
          />
        )}

        {/* ── Input Bar ── */}
        <View style={[s.bar, { paddingBottom: insets.bottom + 8 }]}>

          {micState === 'listening' && (
            <View style={s.liveBanner}>
              <View style={s.liveDot} />
              <Text style={s.liveTxt} numberOfLines={2}>
                {liveText || 'Bol raha hun sunna…'}
              </Text>
            </View>
          )}

          <View style={s.inputRow}>
            <TouchableOpacity
              style={[s.micBtn, { borderColor: micColor, backgroundColor: micColor + '18' }]}
              onPress={handleMic}
              disabled={micState === 'processing' || thinking}
              activeOpacity={0.75}
            >
              {micState === 'processing'
                ? <ActivityIndicator size="small" color={micColor} />
                : <Ionicons name={micIcon as any} size={24} color={micColor} />
              }
            </TouchableOpacity>

            <View style={s.inputWrap}>
              <TextInput
                style={s.input}
                placeholder="Ya type karo…"
                placeholderTextColor={colors.textLight}
                value={inputText}
                onChangeText={setInputText}
                multiline
                maxLength={1000}
                editable={micState === 'idle' && !thinking}
              />
              {thinking
                ? <ActivityIndicator size="small" color={colors.primary} style={{ marginRight: 10 }} />
                : (
                  <TouchableOpacity
                    style={[s.sendBtn, { backgroundColor: inputText.trim() ? colors.primary : colors.border }]}
                    onPress={() => sendToWebhook(inputText)}
                    disabled={!inputText.trim() || micState !== 'idle' || thinking}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="arrow-up" size={17} color="#fff" />
                  </TouchableOpacity>
                )
              }
            </View>
          </View>

          <Text style={s.powered}>
            🎤 Device STT (free) → n8n Webhook · 🔊 Auto voice reply
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  safe:       { flex: 1, backgroundColor: colors.background },
  header:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  hL:         { flexDirection: 'row', alignItems: 'center', gap: 10 },
  badge:      { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  hTitle:     { color: '#fff', fontSize: 16, fontWeight: '700' },
  sRow:       { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  sDot:       { width: 7, height: 7, borderRadius: 4 },
  sTxt:       { color: 'rgba(255,255,255,0.85)', fontSize: 11 },
  hR:         { flexDirection: 'row', gap: 4 },
  hBtn:       { padding: 6 },
  hero:       { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24, paddingBottom: 20 },
  heroTitle:  { fontSize: 21, fontWeight: '700', color: colors.textPrimary, marginTop: 22 },
  heroSub:    { fontSize: 14, color: colors.textSecondary, textAlign: 'center', marginTop: 8, lineHeight: 22 },
  chips:      { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 26, justifyContent: 'center' },
  chip:       { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.card, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 9, borderWidth: 1, borderColor: colors.border, elevation: 2 },
  chipTxt:    { fontSize: 13, color: colors.textPrimary, fontWeight: '500' },
  bar:        { backgroundColor: colors.card, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 10, paddingHorizontal: 12 },
  liveBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FEF2F2', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, marginBottom: 8, borderWidth: 1, borderColor: '#FECACA' },
  liveDot:    { width: 9, height: 9, borderRadius: 5, backgroundColor: '#EF4444' },
  liveTxt:    { flex: 1, fontSize: 13, color: '#DC2626', fontWeight: '500' },
  inputRow:   { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  micBtn:     { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5 },
  inputWrap:  { flex: 1, flexDirection: 'row', alignItems: 'flex-end', backgroundColor: colors.background, borderRadius: 24, borderWidth: 1.5, borderColor: colors.border, paddingLeft: 14, paddingRight: 6, paddingVertical: 6 },
  input:      { flex: 1, fontSize: 15, color: colors.textPrimary, maxHeight: 100, paddingVertical: 4, paddingRight: 6 },
  sendBtn:    { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginLeft: 2 },
  powered:    { textAlign: 'center', fontSize: 10, color: colors.textLight, marginTop: 5, marginBottom: 2 },
});