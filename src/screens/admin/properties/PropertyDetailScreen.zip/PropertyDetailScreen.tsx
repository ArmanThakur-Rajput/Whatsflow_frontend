import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Image, ActivityIndicator, Dimensions, FlatList, Alert, Linking, Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import { usePropertyStore, Property } from '../../../store/propertyStore';
import { colors } from '../../../theme/colors';
import { typography } from '../../../theme/typography';
import { spacing } from '../../../theme/spacing';
import * as FileSystem from 'expo-file-system/legacy';
import * as MediaLibrary from 'expo-media-library';

const { width } = Dimensions.get('window');

// ─── Price display helper ─────────────────────────────────────────────────────
function formatPrice(raw: string | undefined): string {
  if (!raw) return '';
  if (raw.includes('(')) return raw;
  const num = parseFloat(raw.replace(/,/g, ''));
  if (isNaN(num) || num === 0) return raw;
  let short = '';
  if (num >= 10_000_000) short = `${(num / 10_000_000).toFixed(2).replace(/\.?0+$/, '')} Cr`;
  else if (num >= 100_000) short = `${(num / 100_000).toFixed(2).replace(/\.?0+$/, '')} L`;
  else if (num >= 1_000) short = `${(num / 1_000).toFixed(1).replace(/\.?0+$/, '')}k`;
  return short ? `${raw} (${short})` : raw;
}

function InfoRow({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <View style={styles.infoRow}>
      <View style={styles.infoIcon}>
        <Ionicons name={icon as any} size={16} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.infoLabel}>{label}</Text>
        <Text style={styles.infoValue}>{value}</Text>
      </View>
    </View>
  );
}

export default function PropertyDetailScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { propertyId } = route.params as { propertyId: string };
  const { getPropertyById, deleteProperty } = usePropertyStore();

  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [photoViewerVisible, setPhotoViewerVisible] = useState(false);
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);
  const [downloading, setDownloading] = useState(false);

  const handleDelete = () => {
    Alert.alert(
      'Delete Property',
      'This will permanently delete this property and all its photos. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete', style: 'destructive', onPress: async () => {
            try {
              await deleteProperty(propertyId);
              navigation.goBack();
            } catch {
              Alert.alert('Error', 'Failed to delete property');
            }
          },
        },
      ]
    );
  };

  const savePhotoToGallery = async (uri: string) => {
    if (!uri) throw new Error('Photo URL is missing');
    const permission = await MediaLibrary.requestPermissionsAsync();
    if (!permission.granted) {
      throw new Error('Gallery permission is required to save photos.');
    }

    let localUri = uri;
    if (/^https?:\/\//i.test(uri)) {
      const extension = uri.split('?')[0].match(/\.(jpg|jpeg|png|webp|heic)$/i)?.[0] || '.jpg';
      const target = `${FileSystem.cacheDirectory}property_${Date.now()}_${Math.random().toString(36).slice(2)}${extension}`;
      const result = await FileSystem.downloadAsync(uri, target);
      localUri = result.uri;
    }

    await MediaLibrary.saveToLibraryAsync(localUri);
  };

  const handleDownloadCurrentPhoto = async () => {
    const photos = property?.photos || [];
    const photoUri = photos[activePhotoIndex];
    if (!photoUri || downloading) return;
    setDownloading(true);
    try {
      await savePhotoToGallery(photoUri);
      Alert.alert('Photo saved', 'This photo has been saved to your gallery.');
    } catch (error: any) {
      Alert.alert('Could not save photo', error?.message || 'Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadAllPhotos = async () => {
    const photos = property?.photos || [];
    if (!photos.length || downloading) return;
    setDownloading(true);
    let saved = 0;
    try {
      const permission = await MediaLibrary.requestPermissionsAsync();
      if (!permission.granted) {
        throw new Error('Gallery permission is required to save photos.');
      }
      for (const uri of photos) {
        try {
          await savePhotoToGallery(uri);
          saved += 1;
        } catch (error) {
          console.warn('Could not save one property photo:', error);
        }
      }
      if (saved === photos.length) {
        Alert.alert('Photos saved', `All ${saved} photos have been saved to your gallery.`);
      } else {
        Alert.alert('Download finished', `${saved} of ${photos.length} photos were saved. Please check the photo URLs and try again for any missing photos.`);
      }
    } catch (error: any) {
      Alert.alert('Could not save photos', error?.message || 'Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  const handleWhatsAppShare = async () => {
    const shareText = [
      `🏡 ${property.projectName}`,
      property.propertyType ? `Type: ${property.propertyType}` : '',
      property.intent ? `For: ${property.intent === 'buy' ? 'Sale' : 'Rent'}` : '',
      property.price ? `Price: ₹ ${formatPrice(property.price)}` : '',
      property.location ? `Location: ${property.location}` : '',
      property.carpetArea ? `Carpet Area: ${property.carpetArea}` : '',
      property.flatConfig ? `Configuration: ${property.flatConfig}` : '',
      property.notes ? `Details: ${property.notes}` : '',
    ].filter(Boolean).join('\\n');

    const url = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    try {
      await Linking.openURL(url);
    } catch {
      Alert.alert('WhatsApp unavailable', 'Please install WhatsApp or try sharing again.');
    }
  };

  useEffect(() => {
    getPropertyById(propertyId)
      .then(setProperty)
      .catch(() => navigation.goBack())
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <ActivityIndicator style={{ flex: 1 }} color={colors.primary} />
      </SafeAreaView>
    );
  }

  if (!property) return null;

  const statusColor = property.status === 'available' ? colors.success : property.status === 'sold' ? colors.error : colors.warning;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={20} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle} numberOfLines={1}>{property.projectName}</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.deleteBtn} onPress={handleDelete}>
            <Ionicons name="trash-outline" size={18} color={colors.error} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* Photos */}
        {(property.photos?.length ?? 0) > 0 && (
          <View>
            <FlatList
              data={property.photos || []}
              horizontal
              pagingEnabled
              keyExtractor={(u, index) => `${index}-${u}`}
              showsHorizontalScrollIndicator={false}
              style={styles.photoStrip}
              renderItem={({ item, index }) => (
                <TouchableOpacity activeOpacity={0.92} onPress={() => { setActivePhotoIndex(index); setPhotoViewerVisible(true); }}>
                  <Image source={{ uri: item }} resizeMode="cover" style={styles.propertyPhoto} />
                </TouchableOpacity>
              )}
            />
            <Text style={styles.photoHint}>Tap a photo to view full screen · {property.photos.length} photo{property.photos.length === 1 ? '' : 's'}</Text>
          </View>
        )}

        {/* Status + Title */}
        <View style={styles.card}>
          <View style={[styles.statusBadge, { backgroundColor: statusColor + '18' }]}>
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[styles.statusText, { color: statusColor }]}>
              {property.status === 'available' ? 'Available' : property.status === 'sold' ? 'Sold' : 'Rented'}
            </Text>
          </View>
          <Text style={styles.name}>{property.projectName}</Text>
          <Text style={styles.sub}>{property.propertyType} · {property.intent === 'buy' ? 'For Sale' : 'For Rent'}</Text>
          {property.price ? <Text style={styles.price}>₹ {formatPrice(property.price)}</Text> : null}
        </View>

        {/* Property Details — show every saved field from Add/Edit Property */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Property Details</Text>
          <InfoRow icon="location-outline" label="Location" value={property.location || '—'} />
          {property.address && <InfoRow icon="map-outline" label="Address" value={property.address} />}
          {property.floor && <InfoRow icon="layers-outline" label="Floor" value={property.floor === 'Ground' ? 'Ground Floor' : `${property.floor}${/^\d+$/.test(property.floor) ? (Number(property.floor) % 100 >= 11 && Number(property.floor) % 100 <= 13 ? 'th' : ({1:'st',2:'nd',3:'rd'} as Record<number,string>)[Number(property.floor) % 10] || 'th') : ''} Floor`} />}
          {property.flatConfig && <InfoRow icon="home-outline" label="Configuration" value={property.flatConfig} />}
          {property.carpetArea && <InfoRow icon="expand-outline" label="Carpet Area" value={`${property.carpetArea}${/sq\.?\s*ft|sqft/i.test(property.carpetArea) ? '' : ' sqft'}`} />}
          {property.buildupArea && <InfoRow icon="grid-outline" label="Buildup Area" value={`${property.buildupArea}${/sq\.?\s*ft|sqft/i.test(property.buildupArea) ? '' : ' sqft'}`} />}
          {property.plotArea && <InfoRow icon="map-outline" label="Plot Area" value={property.plotArea} />}
          {property.buildingArea && <InfoRow icon="business-outline" label="Building Area" value={property.buildingArea} />}
          {property.flatsOnFloor && <InfoRow icon="business-outline" label="Flats on Same Floor" value={property.flatsOnFloor} />}
          {property.wings && <InfoRow icon="git-branch-outline" label="Wings" value={property.wings} />}
          {property.facing && <InfoRow icon="compass-outline" label="Facing" value={property.facing} />}
          {property.sanction && <InfoRow icon="document-attach-outline" label="Sanction" value={property.sanction} />}
          {property.parking && <InfoRow icon="car-outline" label="Parking" value={property.parking} />}
          {property.water && <InfoRow icon="water-outline" label="Water Source" value={property.water} />}
          {property.lift && <InfoRow icon="business-outline" label="Lift" value={property.lift} />}
          {property.amenities?.length ? (
            <InfoRow icon="checkmark-circle-outline" label="Amenities" value={property.amenities.join(', ')} />
          ) : null}
          {property.gmapsLink && <InfoRow icon="navigate-outline" label="Google Maps Link" value={property.gmapsLink} />}
          {property.notes && <InfoRow icon="document-text-outline" label="Notes" value={property.notes} />}
        </View>

        {/* Contact Details */}
        {(property.ownerName || property.ownerPhone || property.tenantPhone) && (
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Contact Details</Text>
            {property.ownerName && <InfoRow icon="person-outline" label="Owner Name" value={property.ownerName} />}
            {property.ownerPhone && <InfoRow icon="call-outline" label="Owner Phone" value={property.ownerPhone} />}
            {property.tenantPhone && <InfoRow icon="call-outline" label="Tenant Phone" value={property.tenantPhone} />}
          </View>
        )}

        {/* Actions */}
        <View style={styles.actionsCard}>
          <TouchableOpacity
            style={styles.actionBtn}
            onPress={handleWhatsAppShare}
          >
            <Ionicons name="logo-whatsapp" size={20} color="#25D366" />
            <Text style={[styles.actionText, { color: '#25D366' }]}>WhatsApp</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionBtn}
            onPress={() => navigation.navigate('UploadPropertyPhotos', { propertyId: property._id, isEdit: true })}
          >
            <Ionicons name="images-outline" size={20} color={colors.success} />
            <Text style={[styles.actionText, { color: colors.success }]}>Photos</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={handleDelete}>
            <Ionicons name="trash-outline" size={20} color={colors.error} />
            <Text style={[styles.actionText, { color: colors.error }]}>Delete</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>

      <Modal
        visible={photoViewerVisible}
        animationType="fade"
        presentationStyle="fullScreen"
        onRequestClose={() => setPhotoViewerVisible(false)}
      >
        <SafeAreaView style={styles.viewerContainer} edges={['top', 'bottom']}>
          <View style={styles.viewerHeader}>
            <TouchableOpacity style={styles.viewerIconBtn} onPress={() => setPhotoViewerVisible(false)} accessibilityLabel="Close photo viewer">
              <Ionicons name="close" size={25} color="#FFFFFF" />
            </TouchableOpacity>
            <Text style={styles.viewerCounter}>{activePhotoIndex + 1} / {property.photos?.length || 0}</Text>
            <View style={{ width: 42 }} />
          </View>

          <FlatList
            data={property.photos || []}
            horizontal
            pagingEnabled
            initialScrollIndex={activePhotoIndex}
            getItemLayout={(_, index) => ({ length: width, offset: width * index, index })}
            keyExtractor={(uri, index) => `viewer-${index}-${uri}`}
            showsHorizontalScrollIndicator={false}
            onMomentumScrollEnd={(event) => {
              const nextIndex = Math.round(event.nativeEvent.contentOffset.x / width);
              setActivePhotoIndex(nextIndex);
            }}
            renderItem={({ item }) => (
              <View style={styles.viewerPage}>
                <Image source={{ uri: item }} resizeMode="contain" style={styles.viewerImage} />
              </View>
            )}
          />

          <View style={styles.viewerActions}>
            <TouchableOpacity style={styles.viewerActionBtn} onPress={handleDownloadCurrentPhoto} disabled={downloading}>
              {downloading ? <ActivityIndicator color="#FFFFFF" /> : <Ionicons name="download-outline" size={20} color="#FFFFFF" />}
              <Text style={styles.viewerActionText}>Download this photo</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.viewerActionBtn} onPress={handleDownloadAllPhotos} disabled={downloading}>
              <Ionicons name="download" size={20} color="#FFFFFF" />
              <Text style={styles.viewerActionText}>Download all photos</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.base, paddingVertical: spacing.md,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center',
  },
  headerTitle: { flex: 1, fontSize: typography.lg, fontWeight: typography.bold, color: colors.textPrimary, textAlign: 'center' },
  headerActions: { flexDirection: 'row', gap: spacing.xs },
  deleteBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: colors.error + '18', justifyContent: 'center', alignItems: 'center',
  },
  content: { padding: spacing.base, gap: spacing.md },
  photoStrip: {
    width: width - spacing.base * 2,
    alignSelf: 'center',
    borderRadius: 16,
    marginBottom: 4,
    overflow: 'hidden',
  },
  photoStripContent: { alignItems: 'center' },
  photoHint: { textAlign: 'center', fontSize: typography.xs, color: colors.textSecondary, marginTop: 6 },
  propertyPhoto: {
    width: width - spacing.base * 2,
    height: 205,
    borderRadius: 16,
    backgroundColor: colors.border,
  },
  card: {
    backgroundColor: colors.white, borderRadius: 16, padding: spacing.base, gap: spacing.sm,
    elevation: 1, shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3,
  },
  statusBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    alignSelf: 'flex-start', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4,
  },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusText: { fontSize: typography.xs, fontWeight: typography.bold },
  name: { fontSize: typography.xl, fontWeight: typography.bold, color: colors.textPrimary },
  sub: { fontSize: typography.sm, color: colors.textSecondary },
  price: { fontSize: typography.xxl, fontWeight: typography.bold, color: colors.primary },
  sectionTitle: { fontSize: typography.md, fontWeight: typography.bold, color: colors.textPrimary, marginBottom: 4 },
  infoRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm },
  infoIcon: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: colors.primaryLight, justifyContent: 'center', alignItems: 'center',
    marginTop: 2,
  },
  infoLabel: { fontSize: typography.xs, color: colors.textSecondary, marginBottom: 1 },
  infoValue: { fontSize: typography.base, color: colors.textPrimary },
  actionsCard: {
    backgroundColor: colors.white, borderRadius: 16, padding: spacing.md,
    flexDirection: 'row', gap: spacing.sm,
    elevation: 1, shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3,
  },
  actionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.xs, paddingVertical: spacing.md,
    backgroundColor: colors.background, borderRadius: 12,
  },
  actionText: { fontSize: typography.sm, fontWeight: typography.bold },

  viewerContainer: { flex: 1, backgroundColor: '#080808' },
  viewerHeader: {
    height: 54, paddingHorizontal: spacing.base, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'space-between',
  },
  viewerIconBtn: {
    width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#252525',
  },
  viewerCounter: { color: '#FFFFFF', fontSize: typography.base, fontWeight: '600' },
  viewerPage: { width, flex: 1, alignItems: 'center', justifyContent: 'center' },
  viewerImage: { width, height: '100%' },
  viewerActions: { paddingHorizontal: spacing.base, paddingTop: spacing.md, paddingBottom: spacing.md, gap: spacing.sm },
  viewerActionBtn: {
    minHeight: 48, borderRadius: 12, backgroundColor: '#242424', flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: spacing.sm, paddingHorizontal: spacing.md,
  },
  viewerActionText: { color: '#FFFFFF', fontSize: typography.base, fontWeight: '600' },
});
