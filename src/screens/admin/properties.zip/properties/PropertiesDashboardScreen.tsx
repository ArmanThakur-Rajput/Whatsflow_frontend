import React, { useCallback, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, ActivityIndicator, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { usePropertyStore } from '../../../store/propertyStore';
import { colors } from '../../../theme/colors';
import { typography } from '../../../theme/typography';
import { spacing } from '../../../theme/spacing';

function StatCard({
  icon, label, value, bg, iconColor, onPress,
}: {
  icon: string; label: string; value: number;
  bg: string; iconColor: string; onPress?: () => void;
}) {
  return (
    <TouchableOpacity
      style={[styles.statCard, { backgroundColor: bg }]}
      onPress={onPress}
      activeOpacity={onPress ? 0.75 : 1}
    >
      <View style={[styles.statIcon, { backgroundColor: iconColor + '20' }]}>
        <Ionicons name={icon as any} size={22} color={iconColor} />
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

export default function PropertiesDashboardScreen() {
  const navigation = useNavigation<any>();
  const { stats, fetchStats, properties, fetchProperties } = usePropertyStore();
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [recentProps, setRecentProps] = useState<any[]>([]);

  const load = useCallback(async () => {
    await fetchStats();
    // Fetch recent properties (all, sorted by newest)
    try {
      await fetchProperties({});
    } catch {}
    setLoading(false);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  // Get top 3 most recently added properties
  const recent = [...(properties || [])]
    .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
    .slice(0, 3);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchStats();
    await fetchProperties({});
    setRefreshing(false);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Properties</Text>
          <Text style={styles.headerSub}>Inventory Overview</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('AddProperty')}>
          <Ionicons name="add" size={22} color={colors.white} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        {/* ── KIN PROPERTY MANAGEMENT HEADER ── */}
        <View style={styles.kinBanner}>
          <View style={styles.kinLeft}>
            <View style={styles.kinIconWrap}>
              <Ionicons name="business" size={28} color={colors.white} />
            </View>
            <View>
              <Text style={styles.kinTitle}>KIN</Text>
              <Text style={styles.kinSub}>Property Management Centre</Text>
            </View>
          </View>
          <Ionicons name="home" size={48} color={colors.white} style={{ opacity: 0.15 }} />
        </View>

        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
        ) : (
          <>
            <Text style={styles.sectionTitle}>OVERVIEW</Text>
            <View style={styles.statsRow}>
              <StatCard
                icon="home-outline" label="Total" value={stats.total}
                bg={colors.white} iconColor={colors.primary}
                onPress={() => navigation.navigate('ExploreProperties', { filterStatus: 'all' })}
              />
              <StatCard
                icon="checkmark-circle-outline" label="Available" value={stats.available}
                bg={colors.white} iconColor={colors.success}
                onPress={() => navigation.navigate('ExploreProperties', { filterStatus: 'available' })}
              />
              <StatCard
                icon="archive-outline" label="Sold/Rented" value={stats.sold}
                bg={colors.white} iconColor={colors.warning}
                onPress={() => navigation.navigate('ExploreProperties', { filterStatus: 'sold' })}
              />
            </View>

            <Text style={styles.sectionTitle}>QUICK ACTIONS</Text>
            <TouchableOpacity style={styles.addPropertyFull} onPress={() => navigation.navigate('AddProperty')}>
              <View style={[styles.actionIcon, { backgroundColor: colors.primary + '15' }]}>
                <Ionicons name="add-circle-outline" size={26} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.actionTitle}>Add Property</Text>
                <Text style={styles.actionSub}>List a new property to inventory</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textLight} />
            </TouchableOpacity>

            {/* ── RECENT UPLOADS ── */}
            {recent.length > 0 && (
              <>
                <Text style={styles.sectionTitle}>RECENT UPLOADS</Text>
                <View style={styles.recentList}>
                  {recent.map((prop) => {
                    const statusColor = prop.status === 'available' ? colors.success : prop.status === 'sold' ? colors.error : colors.warning;
                    return (
                      <TouchableOpacity
                        key={prop._id}
                        style={styles.recentCard}
                        onPress={() => navigation.navigate('PropertyDetail', { propertyId: prop._id })}
                        activeOpacity={0.82}
                      >
                        {prop.photos?.length > 0 ? (
                          <Image source={{ uri: prop.photos[0] }} style={styles.recentThumb} />
                        ) : (
                          <View style={[styles.recentThumb, styles.recentThumbPlaceholder]}>
                            <Ionicons name="image-outline" size={22} color={colors.textLight} />
                          </View>
                        )}
                        <View style={{ flex: 1 }}>
                          <Text style={styles.recentName} numberOfLines={1}>{prop.projectName}</Text>
                          <Text style={styles.recentMeta} numberOfLines={1}>{prop.propertyType} · {prop.location}</Text>
                          {prop.price ? <Text style={styles.recentPrice}>₹ {prop.price}</Text> : null}
                        </View>
                        <View style={[styles.recentBadge, { backgroundColor: statusColor + '18' }]}>
                          <Text style={[styles.recentBadgeText, { color: statusColor }]}>
                            {prop.status === 'available' ? 'Avail' : prop.status === 'sold' ? 'Sold' : 'Rented'}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.base, paddingVertical: spacing.md,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  headerTitle: { fontSize: typography.xl, fontWeight: typography.bold, color: colors.textPrimary },
  headerSub: { fontSize: typography.xs, color: colors.textSecondary, marginTop: 1 },
  addBtn: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center',
  },
  content: { padding: spacing.base, gap: spacing.md, paddingBottom: spacing.xxxl },

  // KIN Banner
  kinBanner: {
    borderRadius: 18, padding: spacing.base + 4,
    backgroundColor: colors.primary,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    overflow: 'hidden',
  },
  kinLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  kinIconWrap: {
    width: 50, height: 50, borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center', alignItems: 'center',
  },
  kinTitle: { fontSize: 26, fontWeight: '900', color: colors.white, letterSpacing: 2 },
  kinSub: { fontSize: typography.xs, color: colors.white, opacity: 0.85, marginTop: 1 },

  sectionTitle: {
    fontSize: typography.xs, fontWeight: typography.bold,
    color: colors.textSecondary, letterSpacing: 0.8,
    textTransform: 'uppercase', marginTop: spacing.xs,
  },
  statsRow: { flexDirection: 'row', gap: spacing.sm },
  statCard: {
    flex: 1, borderRadius: 16, padding: spacing.md, alignItems: 'center', gap: spacing.xs,
    elevation: 1, shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3,
  },
  statIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  statValue: { fontSize: typography.xxl, fontWeight: typography.bold, color: colors.textPrimary },
  statLabel: { fontSize: typography.xs, color: colors.textSecondary, textAlign: 'center' },

  addPropertyFull: {
    backgroundColor: colors.white, borderRadius: 16, padding: spacing.base,
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    elevation: 1, shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3,
  },
  actionIcon: { width: 52, height: 52, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  actionTitle: { fontSize: typography.base, fontWeight: typography.bold, color: colors.textPrimary },
  actionSub: { fontSize: typography.xs, color: colors.textSecondary, marginTop: 2 },

  // Recent
  recentList: { gap: spacing.sm },
  recentCard: {
    backgroundColor: colors.white, borderRadius: 14, padding: spacing.sm + 2,
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    elevation: 1, shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3,
  },
  recentThumb: { width: 58, height: 58, borderRadius: 10 },
  recentThumbPlaceholder: { backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' },
  recentName: { fontSize: typography.base, fontWeight: typography.bold, color: colors.textPrimary },
  recentMeta: { fontSize: typography.xs, color: colors.textSecondary, marginTop: 2 },
  recentPrice: { fontSize: typography.sm, fontWeight: typography.semiBold, color: colors.primary, marginTop: 2 },
  recentBadge: { borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4 },
  recentBadgeText: { fontSize: typography.xs, fontWeight: typography.bold },
});
