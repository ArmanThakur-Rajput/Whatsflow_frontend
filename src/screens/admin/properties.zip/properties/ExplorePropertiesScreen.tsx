import React, { useState, useCallback, useMemo } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  ActivityIndicator, Modal, Linking, TextInput, Platform,
  Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import DateTimePicker from '@react-native-community/datetimepicker';
import Toast from 'react-native-toast-message';
import { usePropertyStore, LocationSummary, TypeSummary, Property } from '../../../store/propertyStore';
import axiosInstance from '../../../api/axiosInstance';
import { colors } from '../../../theme/colors';
import { typography } from '../../../theme/typography';
import { spacing } from '../../../theme/spacing';

// ─── Highlight text ───────────────────────────────────────────────────────────
function HL({ text, query, style }: { text: string; query: string; style?: any }) {
  if (!query.trim() || !text) return <Text style={style}>{text}</Text>;
  const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const parts = text.split(new RegExp(`(${escaped})`, 'gi'));
  return (
    <Text style={style}>
      {parts.map((part, i) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <Text key={i} style={hlStyle.match}>{part}</Text>
        ) : (
          <Text key={i}>{part}</Text>
        )
      )}
    </Text>
  );
}
const hlStyle = StyleSheet.create({
  match: { backgroundColor: '#FFF176', color: '#1a1a1a', fontWeight: '700', borderRadius: 2 },
});

// ─── Search bar ───────────────────────────────────────────────────────────────
function SearchBar({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <View style={sb.wrap}>
      <Ionicons name="search-outline" size={17} color={colors.textSecondary} />
      <TextInput
        style={sb.input}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={colors.textLight}
        returnKeyType="search"
        autoCorrect={false}
      />
      {value.length > 0 && (
        <TouchableOpacity onPress={() => onChange('')} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="close-circle" size={17} color={colors.textLight} />
        </TouchableOpacity>
      )}
    </View>
  );
}
const sb = StyleSheet.create({
  wrap: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.white, borderRadius: 12,
    borderWidth: 1.5, borderColor: colors.border,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2,
    margin: spacing.base, marginBottom: 0,
  },
  input: { flex: 1, fontSize: typography.base, color: colors.textPrimary, padding: 0 },
});

// ─── Export CSV Modal ─────────────────────────────────────────────────────────
function ExportModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const [fromDate, setFromDate] = useState(new Date());
  const [toDate, setToDate] = useState(new Date());
  const [showFrom, setShowFrom] = useState(false);
  const [showTo, setShowTo] = useState(false);
  const [exporting, setExporting] = useState(false);

  const pad = (n: number) => String(n).padStart(2, '0');

  const handleExport = async () => {
    setExporting(true);
    try {
      const fromStr = `${fromDate.getFullYear()}-${pad(fromDate.getMonth() + 1)}-${pad(fromDate.getDate())}`;
      const toStr = `${toDate.getFullYear()}-${pad(toDate.getMonth() + 1)}-${pad(toDate.getDate())}`;
      const { storage } = await import('../../../utils/storage');
      const token = await storage.getToken();
      const url = `${axiosInstance.defaults.baseURL}/property-crm/export?dateFrom=${fromStr}&dateTo=${toStr}`;
      const fileName = `Properties_${fromStr}_to_${toStr}.csv`;

      if (Platform.OS === 'web') {
        const response = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
        if (!response.ok) throw new Error('Export failed');
        const blob = await response.blob();
        const objectUrl = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = objectUrl; anchor.download = fileName;
        document.body.appendChild(anchor); anchor.click();
        document.body.removeChild(anchor); URL.revokeObjectURL(objectUrl);
      } else {
        const fileUri = FileSystem.documentDirectory + fileName;
        const downloadRes = await FileSystem.downloadAsync(url, fileUri, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (await Sharing.isAvailableAsync()) {
          await Sharing.shareAsync(downloadRes.uri, {
            mimeType: 'text/csv', dialogTitle: 'Save Properties Export',
            UTI: 'public.comma-separated-values-text',
          });
        }
      }
      Toast.show({ type: 'success', text1: 'Properties exported ✅' });
      onClose();
    } catch (err: any) {
      Toast.show({ type: 'error', text1: 'Export failed', text2: err?.message });
    } finally {
      setExporting(false);
    }
  };

  const fmtDate = (d: Date) => d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={exp.overlay} onPress={onClose}>
        <Pressable style={exp.sheet} onPress={() => {}}>
          <View style={exp.header}>
            <Ionicons name="download-outline" size={22} color="#059669" />
            <Text style={exp.title}>Export Properties to CSV</Text>
          </View>
          <Text style={exp.sub}>Select date range based on property creation date</Text>

          <Text style={exp.label}>From Date</Text>
          <TouchableOpacity style={exp.dateBtn} onPress={() => setShowFrom(true)}>
            <Ionicons name="calendar-outline" size={18} color={colors.primary} />
            <Text style={exp.dateText}>{fmtDate(fromDate)}</Text>
          </TouchableOpacity>
          {showFrom && (
            <DateTimePicker value={fromDate} mode="date" display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              maximumDate={toDate}
              onChange={(_e, d) => { setShowFrom(Platform.OS === 'ios'); if (d) setFromDate(d); }} />
          )}

          <Text style={[exp.label, { marginTop: spacing.md }]}>To Date</Text>
          <TouchableOpacity style={exp.dateBtn} onPress={() => setShowTo(true)}>
            <Ionicons name="calendar-outline" size={18} color={colors.primary} />
            <Text style={exp.dateText}>{fmtDate(toDate)}</Text>
          </TouchableOpacity>
          {showTo && (
            <DateTimePicker value={toDate} mode="date" display={Platform.OS === 'ios' ? 'spinner' : 'default'}
              minimumDate={fromDate} maximumDate={new Date()}
              onChange={(_e, d) => { setShowTo(Platform.OS === 'ios'); if (d) setToDate(d); }} />
          )}

          <View style={exp.actions}>
            <TouchableOpacity style={exp.cancelBtn} onPress={onClose} disabled={exporting}>
              <Text style={exp.cancelText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[exp.confirmBtn, exporting && { opacity: 0.6 }]} onPress={handleExport} disabled={exporting}>
              {exporting ? <ActivityIndicator size="small" color="#fff" /> : (
                <><Ionicons name="download-outline" size={16} color="#fff" /><Text style={exp.confirmText}>Export CSV</Text></>
              )}
            </TouchableOpacity>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const exp = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: spacing.base },
  sheet: { backgroundColor: colors.white, borderRadius: 20, padding: spacing.base, width: '100%', maxWidth: 420 },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  title: { fontSize: typography.lg, fontWeight: typography.bold, color: colors.textPrimary },
  sub: { fontSize: typography.sm, color: colors.textSecondary, marginBottom: spacing.md },
  label: { fontSize: typography.sm, fontWeight: typography.semiBold, color: colors.textPrimary, marginBottom: 6 },
  dateBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.background, borderRadius: 12,
    borderWidth: 1.5, borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2,
  },
  dateText: { fontSize: typography.base, color: colors.textPrimary },
  actions: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.lg },
  cancelBtn: { flex: 1, borderRadius: 12, paddingVertical: spacing.md, alignItems: 'center', backgroundColor: colors.background },
  cancelText: { fontSize: typography.base, fontWeight: typography.semiBold, color: colors.textSecondary },
  confirmBtn: {
    flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.sm, borderRadius: 12, paddingVertical: spacing.md, backgroundColor: '#059669',
  },
  confirmText: { fontSize: typography.base, fontWeight: typography.bold, color: '#fff' },
});

// ─── Status Modal ─────────────────────────────────────────────────────────────
function StatusModal({ visible, property, onClose, onStatusChange }: {
  visible: boolean; property: Property | null;
  onClose: () => void; onStatusChange: (id: string, status: 'available' | 'sold' | 'rented') => void;
}) {
  if (!property) return null;
  const OPTIONS = [
    { label: 'Available', value: 'available' as const, color: colors.success, icon: 'checkmark-circle-outline' },
    { label: 'Sold', value: 'sold' as const, color: colors.error, icon: 'close-circle-outline' },
    { label: 'Rented Out', value: 'rented' as const, color: colors.warning, icon: 'home-outline' },
  ];
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <TouchableOpacity style={sm.overlay} onPress={onClose} />
      <View style={sm.sheet}>
        <View style={sm.handle} />
        <Text style={sm.title}>Update Status</Text>
        <Text style={sm.sub}>{property.projectName}</Text>
        {OPTIONS.map((o) => (
          <TouchableOpacity
            key={o.value}
            style={[sm.option, property.status === o.value && { backgroundColor: o.color + '10', borderRadius: 12, paddingHorizontal: spacing.sm }]}
            onPress={() => { onStatusChange(property._id, o.value); onClose(); }}
          >
            <Ionicons name={o.icon as any} size={22} color={o.color} />
            <Text style={[sm.optionText, { color: o.color }]}>{o.label}</Text>
            {property.status === o.value && <Ionicons name="checkmark" size={18} color={o.color} />}
          </TouchableOpacity>
        ))}
      </View>
    </Modal>
  );
}
const sm = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)' },
  sheet: {
    backgroundColor: colors.white, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    paddingHorizontal: spacing.base, paddingBottom: spacing.xxl,
    position: 'absolute', bottom: 0, left: 0, right: 0,
  },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: 'center', marginVertical: spacing.sm },
  title: { fontSize: typography.md, fontWeight: typography.bold, color: colors.textPrimary },
  sub: { fontSize: typography.sm, color: colors.textSecondary, marginBottom: spacing.sm },
  option: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  optionText: { flex: 1, fontSize: typography.base, fontWeight: typography.semiBold },
});

// ─── Property Card ────────────────────────────────────────────────────────────
function PropertyCard({ property, query, onStatusTap, onWaTap, onDetailTap, onEditTap }: {
  property: Property; query: string;
  onStatusTap: () => void; onWaTap: () => void; onDetailTap: () => void; onEditTap: () => void;
}) {
  const statusColor = property.status === 'available' ? colors.success : property.status === 'sold' ? colors.error : colors.warning;
  return (
    <TouchableOpacity style={pc.card} onPress={onDetailTap} activeOpacity={0.85}>
      <View style={[pc.statusBadge, { backgroundColor: statusColor + '18' }]}>
        <View style={[pc.dot, { backgroundColor: statusColor }]} />
        <Text style={[pc.statusText, { color: statusColor }]}>
          {property.status === 'available' ? 'Available' : property.status === 'sold' ? 'Sold' : 'Rented'}
        </Text>
      </View>
      <HL text={property.projectName} query={query} style={pc.name} />
      <HL text={`${property.propertyType} · ${property.intent === 'buy' ? 'Buy' : 'Rent'}`} query={query} style={pc.type} />
      {property.price ? <HL text={`₹ ${property.price}`} query={query} style={pc.price} /> : null}
      <View style={pc.metaRow}>
        {property.carpetArea ? <View style={pc.meta}><Ionicons name="expand-outline" size={13} color={colors.textSecondary} /><HL text={`${property.carpetArea} sqft carpet`} query={query} style={pc.metaText} /></View> : null}
        {property.buildupArea ? <View style={pc.meta}><Ionicons name="grid-outline" size={13} color={colors.textSecondary} /><HL text={`${property.buildupArea} sqft buildup`} query={query} style={pc.metaText} /></View> : null}
        {property.parking ? <View style={pc.meta}><Ionicons name="car-outline" size={13} color={colors.textSecondary} /><HL text={property.parking} query={query} style={pc.metaText} /></View> : null}
        {property.location ? <View style={pc.meta}><Ionicons name="location-outline" size={13} color={colors.textSecondary} /><HL text={property.location} query={query} style={pc.metaText} /></View> : null}
      </View>
      <View style={pc.actionsRow}>
        <TouchableOpacity style={pc.actionBtn} onPress={onWaTap}>
          <Ionicons name="logo-whatsapp" size={18} color="#25D366" />
          <Text style={[pc.actionText, { color: '#25D366' }]}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity style={pc.actionBtn} onPress={onStatusTap}>
          <Ionicons name="checkmark-circle-outline" size={18} color={colors.primary} />
          <Text style={[pc.actionText, { color: colors.primary }]}>Status</Text>
        </TouchableOpacity>
        <TouchableOpacity style={pc.actionBtn} onPress={onEditTap}>
          <Ionicons name="pencil-outline" size={18} color={colors.textSecondary} />
          <Text style={[pc.actionText, { color: colors.textSecondary }]}>Edit</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}
const pc = StyleSheet.create({
  card: {
    backgroundColor: colors.white, borderRadius: 16, padding: spacing.base, gap: spacing.sm,
    elevation: 2, shadowColor: colors.shadow, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 4,
  },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4 },
  dot: { width: 7, height: 7, borderRadius: 4 },
  statusText: { fontSize: typography.xs, fontWeight: typography.bold },
  name: { fontSize: typography.md, fontWeight: typography.bold, color: colors.textPrimary },
  type: { fontSize: typography.sm, color: colors.textSecondary },
  price: { fontSize: typography.lg, fontWeight: typography.bold, color: colors.primary },
  metaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  meta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: typography.xs, color: colors.textSecondary },
  actionsRow: {
    flexDirection: 'row', gap: spacing.sm,
    borderTopWidth: 1, borderTopColor: colors.borderLight, paddingTop: spacing.sm, marginTop: 4,
  },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingVertical: spacing.xs + 2, backgroundColor: colors.background, borderRadius: 10 },
  actionText: { fontSize: typography.xs, fontWeight: typography.semiBold },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────
// filterStatus: 'all' | 'available' | 'sold' (passed from dashboard stat cards)
type ViewLevel = 'locations' | 'types' | 'properties';
type StatusFilter = 'available' | 'sold' | 'rented' | 'all';

export default function ExplorePropertiesScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const initFilter: StatusFilter = route.params?.filterStatus || 'available';

  const { locations, types, properties, fetchLocationsSummary, fetchTypesSummary, fetchProperties, setPropertyStatus, isLoading } = usePropertyStore();

  const [view, setView] = useState<ViewLevel>('locations');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>(initFilter);
  const [statusModal, setStatusModal] = useState(false);
  const [selectedProp, setSelectedProp] = useState<Property | null>(null);
  const [showExport, setShowExport] = useState(false);

  useFocusEffect(useCallback(() => { fetchLocationsSummary(); }, []));

  const selectLocation = async (loc: string) => {
    setSearch('');
    setSelectedLocation(loc);
    await fetchTypesSummary(loc);
    setView('types');
  };

  const selectType = async (type: string) => {
    setSearch('');
    setSelectedType(type);
    await fetchProperties({ location: selectedLocation, propertyType: type });
    setView('properties');
  };

  const handleStatusChange = async (id: string, status: 'available' | 'sold' | 'rented') => {
    try {
      await setPropertyStatus(id, status);
      Toast.show({ type: 'success', text1: `Marked as ${status}` });
      await fetchProperties({ location: selectedLocation, propertyType: selectedType });
    } catch { Toast.show({ type: 'error', text1: 'Update failed' }); }
  };

  const openWa = (prop: Property) => {
    const baseUrl = process.env.EXPO_PUBLIC_API_URL?.replace('/api', '');
    const photos = prop.photos?.length
      ? `\n\n📸 Photos: ${baseUrl}/api/property-crm/properties/${prop._id}/gallery`
      : '';
    const msg =
      `🏠 *${prop.projectName}*\n` +
      `Type: ${prop.propertyType} | ${prop.intent === 'buy' ? 'For Sale' : 'For Rent'}\n` +
      `📍 ${prop.location}\n` +
      (prop.address ? `Address: ${prop.address}\n` : '') +
      (prop.price ? `💰 Price: ₹${prop.price}\n` : '') +
      (prop.carpetArea ? `📐 Carpet: ${prop.carpetArea} sqft\n` : '') +
      (prop.buildupArea ? `🏗 Buildup: ${prop.buildupArea} sqft\n` : '') +
      (prop.parking ? `🚗 Parking: ${prop.parking}\n` : '') +
      (prop.amenities?.length ? `✅ Amenities: ${prop.amenities.join(', ')}\n` : '') +
      photos;
    Linking.openURL(`https://wa.me/?text=${encodeURIComponent(msg)}`).catch(() =>
      Toast.show({ type: 'error', text1: 'Could not open WhatsApp' })
    );
  };

  const q = search.trim().toLowerCase();

  const filteredLocations = useMemo(() => {
    if (!q) return locations;
    return locations.filter((l) => l._id.toLowerCase().includes(q));
  }, [locations, q]);

  const filteredTypes = useMemo(() => {
    if (!q) return types;
    return types.filter((t) => t._id.toLowerCase().includes(q));
  }, [types, q]);

  const filteredProperties = useMemo(() => {
    let base = properties;
    // Apply status filter
    if (statusFilter === 'available') {
      base = base.filter((p) => p.status === 'available');
    } else if (statusFilter === 'sold') {
      base = base.filter((p) => p.status === 'sold' || p.status === 'rented');
    }
    if (!q) return base;
    return base.filter((p) =>
      p.projectName?.toLowerCase().includes(q) ||
      p.propertyType?.toLowerCase().includes(q) ||
      p.location?.toLowerCase().includes(q) ||
      p.price?.toLowerCase().includes(q) ||
      p.address?.toLowerCase().includes(q) ||
      p.carpetArea?.toLowerCase().includes(q) ||
      p.buildupArea?.toLowerCase().includes(q) ||
      p.parking?.toLowerCase().includes(q) ||
      p.ownerName?.toLowerCase().includes(q) ||
      p.amenities?.some((a) => a.toLowerCase().includes(q)) ||
      p.notes?.toLowerCase().includes(q)
    );
  }, [properties, q, statusFilter]);

  const headerTitle = view === 'locations' ? 'Properties'
    : view === 'types' ? selectedLocation
    : selectedType;

  const searchPlaceholder = view === 'locations' ? 'Search locations…'
    : view === 'types' ? 'Search property types…'
    : 'Search name, price, area, amenities…';

  const goBack = () => {
    setSearch('');
    if (view === 'types') setView('locations');
    else if (view === 'properties') setView('types');
    else navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={goBack}>
          <Ionicons name="arrow-back" size={20} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle} numberOfLines={1}>{headerTitle}</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.exportBtn} onPress={() => setShowExport(true)}>
            <Ionicons name="download-outline" size={16} color="#059669" />
            <Text style={styles.exportBtnText}>Export CSV</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.addIconBtn} onPress={() => navigation.navigate('AddProperty')}>
            <Ionicons name="add" size={20} color={colors.white} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Breadcrumb */}
      {view !== 'locations' && (
        <View style={styles.breadcrumb}>
          <Ionicons name="location-outline" size={13} color={colors.primary} />
          <Text style={styles.breadcrumbText} numberOfLines={1}>
            {selectedLocation}{view === 'properties' ? ` / ${selectedType}` : ''}
          </Text>
        </View>
      )}

      {/* Status filter tabs — only on properties view */}
      {view === 'properties' && (
        <View style={styles.tabBar}>
          {([
            { key: 'available', label: 'Available', color: colors.success },
            { key: 'sold', label: 'Sold / Rented', color: colors.warning },
            { key: 'all', label: 'All', color: colors.primary },
          ] as { key: StatusFilter; label: string; color: string }[]).map((tab) => (
            <TouchableOpacity
              key={tab.key}
              style={[styles.tab, statusFilter === tab.key && { backgroundColor: tab.color, borderColor: tab.color }]}
              onPress={() => setStatusFilter(tab.key)}
            >
              <Text style={[styles.tabText, statusFilter === tab.key && { color: colors.white }]}>{tab.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* Search bar */}
      <SearchBar value={search} onChange={setSearch} placeholder={searchPlaceholder} />

      {/* Result count */}
      {q.length > 0 && (
        <View style={styles.resultCount}>
          <Text style={styles.resultCountText}>
            {view === 'locations' ? filteredLocations.length
              : view === 'types' ? filteredTypes.length
              : filteredProperties.length} result(s) for "{search}"
          </Text>
        </View>
      )}

      {/* Locations */}
      {view === 'locations' && (
        <FlatList
          data={filteredLocations}
          keyExtractor={(l) => l._id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.locationCard} onPress={() => selectLocation(item._id)}>
              <View style={styles.locationIcon}>
                <Ionicons name="location-outline" size={22} color={colors.primary} />
              </View>
              <View style={styles.locationInfo}>
                <HL text={item._id} query={search} style={styles.locationName} />
                <Text style={styles.locationMeta}>{item.total} properties</Text>
              </View>
              <View style={styles.locationBadges}>
                <View style={styles.badge}><View style={[styles.badgeDot, { backgroundColor: colors.success }]} /><Text style={styles.badgeText}>{item.available} avail</Text></View>
                <View style={styles.badge}><View style={[styles.badgeDot, { backgroundColor: colors.warning }]} /><Text style={styles.badgeText}>{item.sold} sold</Text></View>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textLight} />
            </TouchableOpacity>
          )}
          ListEmptyComponent={<View style={styles.empty}><Ionicons name="location-outline" size={48} color={colors.textLight} /><Text style={styles.emptyTitle}>{q ? 'No matches found' : 'No locations yet'}</Text><Text style={styles.emptySub}>{q ? `No locations matching "${search}"` : 'Add properties to see locations'}</Text></View>}
        />
      )}

      {/* Types */}
      {view === 'types' && (
        <FlatList
          data={filteredTypes}
          keyExtractor={(t) => t._id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.typeCard} onPress={() => selectType(item._id)}>
              <View style={styles.typeIconWrap}><Ionicons name="business-outline" size={22} color={colors.primary} /></View>
              <View style={{ flex: 1 }}>
                <HL text={item._id} query={search} style={styles.typeName} />
                <Text style={styles.typeMeta}>{item.total} properties</Text>
              </View>
              <View style={styles.typeMetrics}>
                <Text style={[styles.typeMetric, { color: colors.success }]}>{item.available} avail</Text>
                <Text style={[styles.typeMetric, { color: colors.warning }]}>{item.sold} sold</Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textLight} />
            </TouchableOpacity>
          )}
          ListEmptyComponent={<View style={styles.empty}><Ionicons name="business-outline" size={48} color={colors.textLight} /><Text style={styles.emptyTitle}>{q ? 'No matches' : 'No types'}</Text></View>}
        />
      )}

      {/* Properties */}
      {view === 'properties' && (
        isLoading ? <ActivityIndicator style={{ marginTop: 40 }} color={colors.primary} /> : (
          <FlatList
            data={filteredProperties}
            keyExtractor={(p) => p._id}
            contentContainerStyle={styles.listContent}
            renderItem={({ item }) => (
              <PropertyCard
                property={item}
                query={search}
                onStatusTap={() => { setSelectedProp(item); setStatusModal(true); }}
                onWaTap={() => openWa(item)}
                onDetailTap={() => navigation.navigate('PropertyDetail', { propertyId: item._id })}
                onEditTap={() => navigation.navigate('AddProperty', { editId: item._id })}
              />
            )}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Ionicons name="home-outline" size={48} color={colors.textLight} />
                <Text style={styles.emptyTitle}>{q ? 'No matches' : `No ${statusFilter === 'all' ? '' : statusFilter} properties`}</Text>
                <Text style={styles.emptySub}>{q ? `Nothing matches "${search}"` : 'Try a different filter'}</Text>
              </View>
            }
          />
        )
      )}

      <StatusModal visible={statusModal} property={selectedProp} onClose={() => setStatusModal(false)} onStatusChange={handleStatusChange} />
      <ExportModal visible={showExport} onClose={() => setShowExport(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.base, paddingVertical: spacing.md,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  backBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { flex: 1, fontSize: typography.lg, fontWeight: typography.bold, color: colors.textPrimary, textAlign: 'center' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  exportBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: '#059669' + '15', borderRadius: 10,
    paddingHorizontal: spacing.sm, paddingVertical: 6,
  },
  exportBtnText: { fontSize: typography.xs, fontWeight: typography.bold, color: '#059669' },
  addIconBtn: {
    width: 34, height: 34, borderRadius: 10,
    backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center',
  },
  breadcrumb: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: spacing.base, paddingVertical: spacing.xs + 2,
    backgroundColor: colors.primaryLight,
  },
  breadcrumbText: { fontSize: typography.xs, color: colors.primary, fontWeight: typography.semiBold, flex: 1 },

  // Status filter tabs
  tabBar: {
    flexDirection: 'row', gap: spacing.sm,
    paddingHorizontal: spacing.base, paddingTop: spacing.sm,
  },
  tab: {
    flex: 1, paddingVertical: spacing.xs + 2, borderRadius: 20,
    alignItems: 'center', borderWidth: 1.5, borderColor: colors.border,
    backgroundColor: colors.white,
  },
  tabText: { fontSize: typography.xs, fontWeight: typography.bold, color: colors.textSecondary },

  resultCount: { paddingHorizontal: spacing.base, paddingVertical: spacing.xs, marginTop: spacing.xs },
  resultCountText: { fontSize: typography.xs, color: colors.textSecondary, fontStyle: 'italic' },
  listContent: { padding: spacing.base, gap: spacing.sm, paddingBottom: spacing.xxxl },

  locationCard: {
    backgroundColor: colors.white, borderRadius: 16, padding: spacing.base,
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    elevation: 1, shadowColor: colors.shadow, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3,
  },
  locationIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: colors.primaryLight, justifyContent: 'center', alignItems: 'center' },
  locationInfo: { flex: 1 },
  locationName: { fontSize: typography.base, fontWeight: typography.bold, color: colors.textPrimary },
  locationMeta: { fontSize: typography.xs, color: colors.textSecondary, marginTop: 2 },
  locationBadges: { gap: 4 },
  badge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  badgeDot: { width: 6, height: 6, borderRadius: 3 },
  badgeText: { fontSize: typography.xs, color: colors.textSecondary },

  typeCard: {
    backgroundColor: colors.white, borderRadius: 14, padding: spacing.base,
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    elevation: 1, shadowColor: colors.shadow, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3,
  },
  typeIconWrap: { width: 42, height: 42, borderRadius: 12, backgroundColor: colors.primaryLight, justifyContent: 'center', alignItems: 'center' },
  typeName: { fontSize: typography.base, fontWeight: typography.bold, color: colors.textPrimary },
  typeMeta: { fontSize: typography.xs, color: colors.textSecondary, marginTop: 2 },
  typeMetrics: { gap: 2, alignItems: 'flex-end' },
  typeMetric: { fontSize: typography.xs, fontWeight: typography.semiBold },

  empty: { alignItems: 'center', paddingTop: 60, gap: spacing.sm },
  emptyTitle: { fontSize: typography.md, fontWeight: typography.bold, color: colors.textPrimary },
  emptySub: { fontSize: typography.sm, color: colors.textSecondary, textAlign: 'center' },
});
